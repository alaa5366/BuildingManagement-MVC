﻿using BuildingManagementMvc.Attributes;
using BuildingManagementMvc.Models;
using BuildingManagementMvc.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BuildingManagementMvc.Controllers;
// ============================================================
//  CategoriesController	الفئات المالية (Expense + Revenue)
// ============================================================
/// <summary>
/// Management of expense and revenue categories (names, colors, order, activation).
/// </summary>
/// <remarks>
/// Access: requires one of the roles <c>superadmin,admin</c>.
/// </remarks>
[Authorize(Roles = "superadmin,admin")]
[HasPermission(AdminPermissions.ManageCategories)]
public class CategoriesController : Controller
{
    private readonly CategoriesService _categories;
    private readonly BuildingsService _buildings;

    /// <summary>
    /// Initializes a new instance of the <see cref="CategoriesController"/> class.
    /// </summary>
    public CategoriesController(CategoriesService categories, BuildingsService buildings)
    {
        _categories = categories;
        _buildings = buildings;
    }

    private string CurrentUserId =>
        User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? "";

    private string? CurrentBuildingId =>
        User.FindFirst("buildingId")?.Value;

    private bool IsSuperAdmin => User.IsInRole("superadmin");

    // ============================================================
    // صفحة الفئات
    // ============================================================
    /// <summary>
    /// Shows the main page of the categories screen.
    /// </summary>
    public async Task<IActionResult> Index()
    {
        if (IsSuperAdmin)
        {
            var buildings = await _buildings.GetSummariesWithCountsAsync();
            return View("ChooseBuilding", buildings);
        }

        var buildingId = CurrentBuildingId;
        if (string.IsNullOrEmpty(buildingId)) return Forbid();

        var building = await _buildings.GetByIdAsync(buildingId);
        if (building == null) return NotFound();

        ViewBag.Building = building;
        ViewBag.ExpenseCategories = _categories.GetExpenseCategories(building);
        ViewBag.RevenueCategories = _categories.GetRevenueCategories(building);
        return View();
    }

    // ============================================================
    // صفحة الفئات لعمارة محددة (Super Admin فقط)
    // ============================================================
    /// <summary>
    /// Shows the category management page of a building.
    /// </summary>
    /// <remarks>
    /// HTTP GET.
    /// </remarks>
    [HttpGet]
    public async Task<IActionResult> Manage(string id)
    {
        if (!IsSuperAdmin) return Forbid();

        var building = await _buildings.GetByIdAsync(id);
        if (building == null) return NotFound();

        ViewBag.Building = building;
        ViewBag.ExpenseCategories = _categories.GetExpenseCategories(building);
        ViewBag.RevenueCategories = _categories.GetRevenueCategories(building);
        return View("Index");
    }

    // ============================================================
    // إضافة فئة
    // ============================================================
    /// <summary>
    /// Handles the add form submission of the categories screen.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(
        string buildingId, bool isExpense, string name, string color)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            TempData["Error"] = Loc.T("Category_Name_Is_Required");
            return RedirectBack(buildingId);
        }

        var building = await _buildings.GetByIdAsync(buildingId);
        if (building == null) return NotFound();

        if (!CanAccessBuilding(buildingId)) return Forbid();

        await _categories.AddAsync(building, isExpense, name, color, CurrentUserId);
        TempData["Message"] = Loc.T("Category_Added");
        return RedirectBack(buildingId);
    }

    // ============================================================
    // تعديل فئة
    // ============================================================
    /// <summary>
    /// Handles the update form submission of the categories screen.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Update(
        string buildingId, bool isExpense, string id,
        string name, string color, bool active)
    {
        var building = await _buildings.GetByIdAsync(buildingId);
        if (building == null) return NotFound();
        if (!CanAccessBuilding(buildingId)) return Forbid();

        var ok = await _categories.UpdateAsync(building, isExpense, id, name, color, active, CurrentUserId);
        TempData[ok ? "Message" : "Error"] = ok ? Loc.T("Updated") : Loc.T("Category_Not_Found");
        return RedirectBack(buildingId);
    }

    // ============================================================
    // حذف / تعطيل فئة
    // ============================================================
    /// <summary>
    /// Handles the delete form submission of the categories screen.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(string buildingId, bool isExpense, string id)
    {
        var building = await _buildings.GetByIdAsync(buildingId);
        if (building == null) return NotFound();
        if (!CanAccessBuilding(buildingId)) return Forbid();

        var ok = await _categories.DeleteAsync(building, isExpense, id, CurrentUserId);
        TempData[ok ? "Message" : "Error"] = ok
            ? Loc.T("Deleted_Or_Disabled_If_In_Use")
            : Loc.T("Category_Not_Found");
        return RedirectBack(buildingId);
    }

    // ============================================================
    // إعادة الترتيب (AJAX)
    // ============================================================
    /// <summary>
    /// Saves a new display order for the expense or revenue categories.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reorder(string buildingId, bool isExpense, List<string> ids)
    {
        var building = await _buildings.GetByIdAsync(buildingId);
        if (building == null) return NotFound();
        if (!CanAccessBuilding(buildingId)) return Forbid();

        await _categories.ReorderAsync(building, isExpense, ids ?? new(), CurrentUserId);
        return Json(new { success = true });
    }

    // ============================================================
    // Helpers
    // ============================================================
    private bool CanAccessBuilding(string buildingId)
    {
        if (IsSuperAdmin) return true;
        return CurrentBuildingId == buildingId;
    }

    private IActionResult RedirectBack(string buildingId)
    {
        if (IsSuperAdmin)
            return RedirectToAction(nameof(Manage), new { id = buildingId });
        return RedirectToAction(nameof(Index));
    }
}
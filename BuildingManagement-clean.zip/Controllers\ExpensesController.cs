using BuildingManagementMvc.Attributes;
using BuildingManagementMvc.Models;
using BuildingManagementMvc.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BuildingManagementMvc.Controllers;
// ============================================================
//  ExpensesController	المصروفات الشهرية
// ============================================================
/// <summary>
/// Monthly expense entry for the current building: list, add and delete.
/// </summary>
/// <remarks>
/// Access: requires one of the roles <c>admin</c>.
/// </remarks>
[Authorize(Roles = "admin")]
[AdminPermission(BuildingManagementMvc.Models.AdminPermissions.ManageExpenses)]
public class ExpensesController : Controller
{
    private readonly BuildingsService _buildings;
    private readonly WalletService _wallet;
    private readonly ExpensesService _expenses;
    private readonly AuditLogService _audit;
    private readonly ILogger<ExpensesController> _logger;

    /// <summary>
    /// Initializes a new instance of the <see cref="ExpensesController"/> class.
    /// </summary>
    public ExpensesController(
        BuildingsService buildings,
        WalletService wallet,
        ExpensesService expenses,
        AuditLogService audit,
        ILogger<ExpensesController> logger)
    {
        _buildings = buildings;
        _wallet = wallet;
        _expenses = expenses;
        _audit = audit;
        _logger = logger;
    }

    private string BuildingId => User.FindFirstValue("buildingId")!;

    /// <summary>
    /// Shows the main page of the expenses screen.
    /// </summary>
    /// <remarks>
    /// HTTP GET.
    /// </remarks>
    [HttpGet]
    public async Task<IActionResult> Index(string? month, int page = 1, int pageSize = 50)
    {
        var building = await _buildings.GetByIdAsync(BuildingId);
        if (building == null) return NotFound();

        var mk = string.IsNullOrWhiteSpace(month) ? WalletService.CurrentMonthKey() : month;
        var m = _wallet.GetOrCreateMonth(building, mk);

        // ✅ كل المصروفات
        var allExpenses = m.Expenses.OrderByDescending(e => e.Date).ToList();

        // ✅ Pagination
        var pagedExpenses = PagedResult<BuildingManagementMvc.Models.Expense>
            .Create(allExpenses, page, pageSize);

        ViewBag.Building = building;
        ViewBag.Month = mk;
        ViewBag.Categories = building.ExpenseCategories.Where(c => c.Active).OrderBy(c => c.Order).ToList();
        ViewBag.Total = m.Expenses.Sum(e => e.Amount);
        ViewBag.RouteValues = new Dictionary<string, string?>
        {
            ["month"] = mk,
            ["pageSize"] = pageSize.ToString()
        };

        return View(pagedExpenses);
    }

    /// <summary>
    /// Handles the add form submission of the expenses screen.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Add(string month, string categoryId, string note, decimal amount, string date)
    {
        var building = await _buildings.GetByIdAsync(BuildingId);
        if (building == null) return NotFound();
        var mk = string.IsNullOrWhiteSpace(month) ? WalletService.CurrentMonthKey() : month;

        try
        {
            if (amount > 0 && !string.IsNullOrWhiteSpace(categoryId))
            {
                _expenses.AddExpense(building, categoryId, note, amount, date, mk);
                _wallet.RecalculateDistribution(building, mk);
                _audit.Push(building, "expense_add", $"{amount:0.##} ج.م — {note}", "admin", User.Identity?.Name ?? "admin");
                await _buildings.SaveFullAsync(building);
                TempData["Message"] = Loc.T("Expense_Added");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to add expense for building {BuildingId}", BuildingId);
            TempData["Error"] = Loc.T("Failed_To_Add_Expense");
        }

        return RedirectToAction("Index", new { month = mk });
    }

    /// <summary>
    /// Handles the delete form submission of the expenses screen.
    /// </summary>
    /// <remarks>
    /// HTTP POST.
    /// </remarks>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(string month, string id)
    {
        var building = await _buildings.GetByIdAsync(BuildingId);
        if (building == null) return NotFound();

        try
        {
            _expenses.DeleteExpense(building, id, month);
            _wallet.RecalculateDistribution(building, month);
            _audit.Push(building, "expense_delete", "حذف مصروف", "admin", User.Identity?.Name ?? "admin");
            await _buildings.SaveFullAsync(building);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to delete expense {ExpenseId}", id);
            TempData["Error"] = Loc.T("Failed_To_Delete_Expense");
        }

        return RedirectToAction("Index", new { month });
    }
}
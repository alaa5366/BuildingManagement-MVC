# Building Management — Backup
تاريخ الإنشاء: 2026-09-28T08:38:29.9881757Z
بواسطة: system-scheduler

## المحتوى:
- buildings.json (العمارات)
- users.json (المستخدمون)
- auditLogs.json (سجل التدقيق)
- qr_usage.json (استخدام QR)
- qr-tokens.json (رموز QR)
- presence.json (الحضور)
- whatsappTemplates.json (قوالب واتساب)

## ملاحظات:
- كل ملف JSON فيه مصفوفة من المستندات.
- كل مستند = { id, data }.
- للاستعادة: استخدم /BackupFull/Restore.
